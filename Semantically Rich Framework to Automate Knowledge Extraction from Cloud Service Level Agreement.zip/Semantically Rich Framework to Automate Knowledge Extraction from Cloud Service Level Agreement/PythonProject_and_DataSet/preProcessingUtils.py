from urllib.request import urlopen
from bs4 import BeautifulSoup
from nltk import word_tokenize, PunktSentenceTokenizer
import os
import shutil
import PyPDF2
from tika import parser

slaURLDict = \
    {
        'GCP' : 'https://cloud.google.com/compute/sla',
        'AWS' : 'https://aws.amazon.com/compute/sla/',
        'Azure' : 'https://azure.microsoft.com/en-us/support/legal/sla/virtual-machines/v1_8/',
        'VMware' : 'https://www.vmware.com/support/vcloud-air/sla.html',
        'IBM':'https://cloud.ibm.com/docs/overview?topic=overview-slas',
        'Alibaba':'https://www.alibabacloud.com/help/doc-detail/42436.htm',
        'RackSpace':'rackspace.pdf',
        'SAP':'sap.pdf',
        'Oracle':'oracle.pdf'

    }

def displayProviders(cloudServiceProviders):
    for eachProvider in cloudServiceProviders:
        print("{0} : {1} ".format(eachProvider,slaURLDict[eachProvider]))

def readFromPDF(provider):

    raw = parser.from_file(slaURLDict.get(provider))
    return raw['content']
    # closing the pdf file object


def getSoup(provider):
    page = urlopen(slaURLDict[provider])
    pageRead = page.read().decode('utf-8', 'ignore')
    page.close()
    soup = BeautifulSoup(pageRead, 'lxml')
    # soup = BeautifulSoup(pageRead, 'html.parser')

    return soup


def getTextFromSoup(soup,provider):
    if provider=="GCP":
        rawText = soup.find_all("div", class_="devsite-article-body clearfix")
        text = ' '.join(map(lambda p: p.text, rawText))
    elif provider=="AWS":
        rawText = soup.find_all("div", {"class":"lb-col lb-tiny-24 lb-mid-24"})
        text = ' '.join(map(lambda p: p.text, rawText))
    elif provider=="Azure":
        rawText = soup.find_all("div", {"class": "section"})
        text = ' '.join(map(lambda p: p.text, rawText))
    elif provider == "VMware":
        rawText = soup.find_all("div", {"class": "container-fluid"})
        text = ' '.join(map(lambda p: p.text, rawText))
    elif provider == "Alibaba":
        rawText = soup.find_all("div", {"class": "col-lg-7 col-md-7 col-sm-8 col-xs-12 doc-content"})
        text = ' '.join(map(lambda p: p.text, rawText))
    elif provider == "IBM":

        rawText = soup.find_all("div")
        text = ' '.join(map(lambda p: p.text, rawText))
    else:
        rawText = soup.find_all("div", class_="devsite-article-body clearfix")
        text = ' '.join(map(lambda p: p.text, rawText))
    return text


def customTokinizer(text):
    custom_token = PunktSentenceTokenizer(text)
    tokenized = custom_token.tokenize(text)
    return tokenized

def tokenizeWords(text):
    print (text)
    print("Tokenizing words...")
    words = word_tokenize(text.decode().lower())

    return words

def createFolders(folders):
    for eachFolder in folders:
        dir = eachFolder
        if os.path.exists(dir):
            shutil.rmtree(dir)
        os.makedirs(dir)

def removeDuplicates(theString):
    theList = []
    for line in theString.split('\n'):
        if line not in theList:
            theList.append(line)

    theMerged = "\n".join(theList)
    return theMerged

def textFormater(text):
    if isinstance(text, list):
        text = "\n".join(text)
        text = text.replace("\n", " ")
        text = text.replace("\r", ".")
        text = text.split(". ")

    else:
        text = text.replace("\n", " ")
        text = text.replace("\r", ".")
        text = "\n".join(text.split(". "))
    print('textFomr : ',text)
    return text

def writePopluationStats(str):
    file = open('PopulationStats.txt','w')
    file.write(str)
    file.close()

def CheckPopulationCount(PermState_Count,PermAct_Count,OblState_Count,OblAct_Count,NonComp_Count):
    count = 0
    if PermState_Count > 0:
        count +=1
    if PermAct_Count > 0:
        count +=1
    if OblState_Count > 0:
        count +=1
    if OblAct_Count > 0:
        count +=1
    if NonComp_Count > 0:
        count +=1
    return count
