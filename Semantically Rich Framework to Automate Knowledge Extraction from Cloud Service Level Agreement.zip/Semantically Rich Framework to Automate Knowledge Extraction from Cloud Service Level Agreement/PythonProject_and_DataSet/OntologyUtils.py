import spacy
from owlready2 import *
import owlready2 as owl
import preProcessingUtils as utils

pdfSLAs = ['RackSpace','SAP', 'Oracle']

deonticDict = \
    {
        'Obligation' : ['must', 'should', 'have to', 'will'],
        'Permission' :  ['can', 'may', 'could']
    }

owlPath = 'C:\\Users\divya\Desktop\Thesis\\cloudSLA_F.owl'
actors = ['aws', 'customer', 'we', 'you', 'amazon', 'google', 'gcp', 'microsoft', 'azure', 'vmware', 'oracle', 'alibaba','Alibaba Could', 'us']


def getDefinitions(provider, tokenized):
    tokenized = utils.textFormater(tokenized)
    print('tokenized : ',tokenized)
    fileName = "Definitions_" + provider + ".txt"
    writeBack = ""
    file = open(fileName, 'w')
    for i in tokenized:
        print('i : ', i)
        r1 = re.findall("[a-zA-Z“ ”:\"]+(?:is calculated | refers | means | is a | is defined | mean )+[\na-zA-Z 0-9!@#$&()\\-`.+,/“:”\*%]+", i)
        if len(r1) != 0:
            writeBack += str(r1) + '\n'

    writeBack = utils.removeDuplicates(writeBack)
    file.write(writeBack)
    file.close()


def getDeonticLogic(provider,text):
    text = utils.textFormater(text)

    for deonticType in deonticDict:
        file = open(deonticType+"Statements_" + provider + ".txt", 'w')
        wordMerge = ""
        counter = 0
        deonticCount = 0
        for s in text:
            counter += 1
            if any(word in s for word in deonticDict[deonticType]):
                deonticCount += 1
                wordMerge += str(s) + '\n'

        wordMerge = utils.removeDuplicates(wordMerge)
        file.write(wordMerge)
        file.close()

def getActors(eachProvider):
    nlp = spacy.load("en_core_web_sm")
    for deonticType in deonticDict:


        f = open(deonticType+'Statements_'+eachProvider+'.txt', 'r', encoding='utf-8', errors='ignore')
        text = f.readlines()
        fw = open(deonticType+'Actors_'+eachProvider+'.txt','w')
        for sent in text:

            doc = nlp(sent)
            Actor = ""
            for previous, current in zip(doc, doc[1:]):
                nouns = ['NNP', 'NN', 'NNS', 'NNPS']
                if ((previous.dep_) == 'nsubj') & ((current.tag_) == 'MD'):
                    Actor = previous
                elif ((previous.dep_) == 'ROOT') & ((current.dep_) == 'dobj'):
                    Actor = current


            fw.writelines("Actor: " + str(Actor) + "    " + "Sentence : " + str(sent) + '\n')

        fw.close()
        f.close()

def getNonComplianceRemedy(soup,provider):
    mergedText = ""
    table = soup.find('table')
    table_rows = table.find_all('tr')
    newonw = open("NonComplianceRemedies_" + provider + ".txt", 'w')
    for tr in table_rows:
        count=0
        th = tr.find_all('th')
        td = tr.find_all('td')
        for i in td:
            if "%" in i.text and provider!='VMware':
                if count == 1:
                    mergedText += '             Service Credit Percentage : '+i.text + '\n'
                    count=0
                else:
                    mergedText += 'Monthly Uptime Percentage: '  + i.text
                    count+=1

    newonw.write(mergedText)
    newonw.close()

def loadOwl():
    onto_path.append(owlPath)
    onto = get_ontology(owlPath)
    onto.load()
    return onto


def createDataProperties(onto):
    with onto:
        class hasRemedyforNonCompliance(DataProperty):
            domain = [onto.RemediesforNonCompliance]
            range = [str]
    with onto:
        class hasObligationActors(DataProperty):
            domain = [onto.Obligation]
            range=[str]
    with onto:
        class hasPermissionActors(DataProperty):
            domain=[onto.Permission]
            range=[str]
    with onto:
        class hasObligationStatements(DataProperty):
            domain=[onto.Obligation]
            range=[str]
            pass
    with onto:
        class hasPermissionStatements(DataProperty):
            domain=[onto.Permission]
            range=[str]
            pass


def createOntStructure(onto):
    with onto:
        class Statments(Thing):
            pass
    with onto:
        class CloudSLA(Thing):
            pass
    with onto:
        class Standards(Thing):
            pass

    with onto:
        class TermAndAdjustments(Thing):
            pass
    with onto:
        class RemediesforNonCompliance(Thing):
            pass

    with onto:
        class DeonticStatements(Thing):
            pass

    with onto:
        class Obligation(DeonticStatements):
            pass

    with onto:
        class Permission(DeonticStatements):
            pass

def createInstances(provider,onto):

    DefState_Count = 0
    PermState_Count = 0
    PermAct_Count = 0
    OblState_Count = 0
    OblAct_Count = 0
    NonComp_Count = 0

    instance = onto.CloudSLA(provider)
    instance.is_a.append(onto.CloudSLA)
    instance.is_a.append(onto.Permission)
    instance.is_a.append(onto.Obligation)
    instance.is_a.append(onto.RemediesforNonCompliance)
    instance.is_a.append(onto.ServiceStandards)

    defStatFile = open("Definitions_" + provider + ".txt", 'r')
    permStatFile = open("PermissionStatements_" + provider + ".txt", 'r')
    obligStatFile = open("ObligationStatements_" + provider + ".txt", 'r')
    permActorFile = open("PermissionActors_" + provider + ".txt", 'r')
    obligActorFile = open("ObligationActors_" + provider + ".txt", 'r')
    if provider not in pdfSLAs:
        nonCompRemFile = open("NonComplianceRemedies_" + provider + ".txt", 'r')

    instance.hasObligationStatements = [""]
    instance.hasPermissionStatements = [""]
    instance.hasPermissionActors = [""]
    instance.hasObligationActors = [""]
    instance.hasRemedyforNonCompliance = [""]
    instance.hasStandards = [""]

    for defStat in defStatFile.readlines():
        DefState_Count += 1
        instance.hasStandards.append(defStat)
    for oligStat in obligStatFile.readlines():
        OblState_Count += 1
        instance.hasObligationStatements.append(oligStat)
    for permStat in permStatFile.readlines():
        PermState_Count += 1
        instance.hasPermissionStatements.append(permStat)
    for permAct in permActorFile.readlines():
        PermAct_Count += 1
        instance.hasPermissionActors.append(permAct)
    for obligAct in obligActorFile.readlines():
        OblAct_Count += 1
        instance.hasObligationActors.append(obligAct)
    if provider not in pdfSLAs:
        for nonCompRem in nonCompRemFile.readlines():
            NonComp_Count += 1
            instance.hasRemedyforNonCompliance.append(nonCompRem)



    populationCount = utils.CheckPopulationCount(PermState_Count,PermAct_Count,OblState_Count,OblAct_Count,NonComp_Count)

    populationStatStr = ('\n######### {} Stats ######### \n '
          '------- Population Count : {} ------- \n '
          'ObligationStatements : {} \n '
          'ObligationActors : {} \n '
          'PermissionStatements : {} \n '
          'PermissionActors : {} \n '
          'RemedyForNonCompliance : {} \n\n'
          .format(provider,populationCount,OblState_Count,OblAct_Count,PermState_Count,PermAct_Count,NonComp_Count))

    return populationStatStr

def clearInstances(onto,fClass):
    with onto:
        class fClass(Thing):
            pass

    for eachClass in onto.get_instances_of(fClass):
        owl.destroy_entity(eachClass)

    onto.save()
