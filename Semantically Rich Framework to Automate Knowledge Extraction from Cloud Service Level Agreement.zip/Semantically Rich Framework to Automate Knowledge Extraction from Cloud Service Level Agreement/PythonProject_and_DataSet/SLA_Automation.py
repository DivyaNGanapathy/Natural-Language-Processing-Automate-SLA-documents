from nltk import sent_tokenize
import preProcessingUtils as utils
import OntologyUtils as ontUtils



cloudServiceProviders = \
[
    'GCP',
    'AWS',
    'Azure',
    'VMware',
    'Alibaba',
    'RackSpace',
    'SAP',
    'Oracle'
]




print("\nProcessing the following SLAs : \n")
utils.displayProviders(cloudServiceProviders)
pdfSLAs = ['RackSpace','SAP', 'Oracle']

for eachProvider in cloudServiceProviders:
    print("Processing - ",eachProvider)
    if eachProvider in pdfSLAs:
        pdfText = utils.readFromPDF(eachProvider)
        tokenized = utils.customTokinizer(pdfText)
        ontUtils.getDefinitions(eachProvider, tokenized)
        ontUtils.getDeonticLogic(eachProvider, sent_tokenize(pdfText))
        ontUtils.getActors(eachProvider)
        # ontUtils.getNonComplianceRemedy(soup, eachProvider)
    else:
        soup = utils.getSoup(eachProvider)
        text = utils.getTextFromSoup(soup,eachProvider)
        tokenized = utils.customTokinizer(text)
        ontUtils.getDefinitions(eachProvider,tokenized)
        ontUtils.getDeonticLogic(eachProvider,sent_tokenize(text))
        ontUtils.getActors(eachProvider)
        ontUtils.getNonComplianceRemedy(soup,eachProvider)


print("Populating Ontology\n")
print("Loading OWL \n")
onto = ontUtils.loadOwl()
# print("Clearning existing instances in OWL")
# ontUtils.clearInstances(onto,['CloudSLA','RemediesforNonCompliance'])
print("Creating data properties \n")
ontUtils.createDataProperties(onto)
print("Creating a struction in the ontology \n")
ontUtils.createOntStructure(onto)

print("Creating instances \n")
populationStatStr = ""
for eachProvider in cloudServiceProviders:
    populationStatStr += ontUtils.createInstances(eachProvider,onto)

utils.writePopluationStats(populationStatStr)

onto.save()

print("Ontology updated and saved!")








